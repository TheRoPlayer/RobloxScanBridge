# Build RobloxScanBridge.exe (optional)
# Requires: Python 3.12 + pyinstaller installed
# Install:   py -3.12 -m pip install pyinstaller
# Build:
py -3.12 -m pyinstaller --onefile --name RobloxScanBridge --clean --noconfirm .\main.py
Write-Host "Done. EXE is in .\dist\RobloxScanBridge.exe"
