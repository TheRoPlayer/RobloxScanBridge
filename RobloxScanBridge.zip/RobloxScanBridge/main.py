"""
RobloxScanBridge (Python 3.12)

What it does:
- Runs a small local HTTP server on 127.0.0.1:8787
- Roblox Studio plugin sends a JSON "scan" payload to POST /scangame
- App estimates scan "complexity time" and writes a report to your Downloads folder

No external dependencies (pure stdlib).
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8787


def downloads_dir() -> Path:
    # Works on Windows and most desktops where ~/Downloads exists.
    # If it doesn't exist, it will fall back to the user's home directory.
    home = Path.home()
    d = home / "Downloads"
    return d if d.exists() else home


def exe_name() -> str:
    # When packaged, sys.argv[0] will be the .exe path; otherwise it's main.py
    return Path(sys.argv[0]).name


@dataclass
class ScanSummary:
    game_name: str
    place_id: Optional[int]
    universe_id: Optional[int]
    scanned_at_utc: str
    studio_user: str

    # Counts
    total_instances: int
    scripts: int
    localscripts: int
    modulescripts: int
    parts: int
    models: int
    folders: int

    # Optional detail
    top_classes: Dict[str, int]
    notes: str

    # Estimate
    estimate_seconds: float

    @staticmethod
    def from_payload(payload: Dict[str, Any]) -> "ScanSummary":
        meta = payload.get("meta", {}) or {}
        counts = payload.get("counts", {}) or {}
        top_classes = payload.get("top_classes", {}) or {}

        total_instances = int(counts.get("total_instances", 0))
        scripts = int(counts.get("scripts", 0))
        localscripts = int(counts.get("localscripts", 0))
        modulescripts = int(counts.get("modulescripts", 0))
        parts = int(counts.get("parts", 0))
        models = int(counts.get("models", 0))
        folders = int(counts.get("folders", 0))

        # Simple heuristic estimator (tweakable).
        # Idea: scripts and module scripts tend to be "heavier" to review/compile/analyze.
        # Parts/models/folders add less weight.
        # This is NOT Roblox compile time — it’s a rough "project complexity" estimate.
        score = (
            total_instances * 0.002
            + scripts * 0.35
            + localscripts * 0.30
            + modulescripts * 0.55
            + parts * 0.01
            + models * 0.04
            + folders * 0.02
        )
        # clamp and scale to seconds
        estimate_seconds = max(2.0, min(3600.0, score * 1.6))

        return ScanSummary(
            game_name=str(meta.get("game_name", "Unknown Game")),
            place_id=_maybe_int(meta.get("place_id")),
            universe_id=_maybe_int(meta.get("universe_id")),
            scanned_at_utc=str(meta.get("scanned_at_utc", datetime.utcnow().isoformat() + "Z")),
            studio_user=str(meta.get("studio_user", "Unknown")),
            total_instances=total_instances,
            scripts=scripts,
            localscripts=localscripts,
            modulescripts=modulescripts,
            parts=parts,
            models=models,
            folders=folders,
            top_classes={str(k): int(v) for k, v in top_classes.items()},
            notes=str(payload.get("notes", "")),
            estimate_seconds=float(estimate_seconds),
        )


def _maybe_int(v: Any) -> Optional[int]:
    try:
        if v is None or v == "":
            return None
        return int(v)
    except Exception:
        return None


class AppState:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.last_scan: Optional[ScanSummary] = None

    def set_scan(self, scan: ScanSummary) -> None:
        with self._lock:
            self.last_scan = scan

    def get_scan(self) -> Optional[ScanSummary]:
        with self._lock:
            return self.last_scan


STATE = AppState()


def format_seconds(s: float) -> str:
    s = max(0.0, float(s))
    whole = int(round(s))
    h = whole // 3600
    m = (whole % 3600) // 60
    sec = whole % 60
    if h > 0:
        return f"{h}h {m}m {sec}s"
    if m > 0:
        return f"{m}m {sec}s"
    return f"{sec}s"


def write_report(scan: ScanSummary) -> Path:
    out_dir = downloads_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S_UTC")
    filename = f"RobloxScanReport_{ts}.txt"
    out_path = out_dir / filename

    lines = []
    lines.append("RobloxScanBridge Report")
    lines.append("=" * 26)
    lines.append(f"Created: {datetime.utcnow().isoformat()}Z")
    lines.append(f"App/EXE: {exe_name()}")
    lines.append("")
    lines.append("Scan Meta")
    lines.append("-" * 8)
    lines.append(f"Game name: {scan.game_name}")
    lines.append(f"Studio user: {scan.studio_user}")
    lines.append(f"PlaceId: {scan.place_id}")
    lines.append(f"UniverseId: {scan.universe_id}")
    lines.append(f"Scanned at (UTC): {scan.scanned_at_utc}")
    lines.append("")
    lines.append("Counts")
    lines.append("-" * 6)
    lines.append(f"Total instances: {scan.total_instances}")
    lines.append(f"Scripts: {scan.scripts}")
    lines.append(f"LocalScripts: {scan.localscripts}")
    lines.append(f"ModuleScripts: {scan.modulescripts}")
    lines.append(f"Parts: {scan.parts}")
    lines.append(f"Models: {scan.models}")
    lines.append(f"Folders: {scan.folders}")
    lines.append("")
    lines.append("Top classes")
    lines.append("-" * 11)
    if scan.top_classes:
        for k, v in sorted(scan.top_classes.items(), key=lambda kv: (-kv[1], kv[0]))[:30]:
            lines.append(f"{k}: {v}")
    else:
        lines.append("(none)")
    lines.append("")
    lines.append("Estimate")
    lines.append("-" * 8)
    lines.append(f"Estimated complexity time: {format_seconds(scan.estimate_seconds)}")
    lines.append("")
    if scan.notes.strip():
        lines.append("Notes")
        lines.append("-" * 5)
        lines.append(scan.notes.strip())
        lines.append("")

    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


class Handler(BaseHTTPRequestHandler):
    server_version = "RobloxScanBridge/1.0"

    def _send_json(self, code: int, obj: Dict[str, Any]) -> None:
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b""
            if not raw:
                return None, "Empty body"
            return json.loads(raw.decode("utf-8")), None
        except Exception as e:
            return None, f"Invalid JSON: {e}"

    def do_GET(self):  # noqa: N802
        if self.path == "/" or self.path.startswith("/health"):
            scan = STATE.get_scan()
            self._send_json(200, {
                "ok": True,
                "app": "RobloxScanBridge",
                "version": "1.0",
                "last_scan": None if scan is None else {
                    "game_name": scan.game_name,
                    "scanned_at_utc": scan.scanned_at_utc,
                    "estimate_seconds": scan.estimate_seconds,
                }
            })
            return

        self._send_json(404, {"ok": False, "error": "Not found"})

    def do_POST(self):  # noqa: N802
        if self.path != "/scangame":
            self._send_json(404, {"ok": False, "error": "Not found"})
            return

        payload, err = self._read_json()
        if err:
            self._send_json(400, {"ok": False, "error": err})
            return

        try:
            scan = ScanSummary.from_payload(payload or {})
            STATE.set_scan(scan)
            report_path = write_report(scan)

            self._send_json(200, {
                "ok": True,
                "message": "Scan received. Report saved.",
                "report_path": str(report_path),
                "estimate_seconds": scan.estimate_seconds,
                "estimate_human": format_seconds(scan.estimate_seconds),
            })
        except Exception as e:
            self._send_json(500, {"ok": False, "error": str(e)})

    def log_message(self, format: str, *args):  # silence default logging
        return


def run_server(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> None:
    httpd = HTTPServer((host, port), Handler)
    print(f"RobloxScanBridge running on http://{host}:{port}")
    print("Keep this window open while Roblox Studio is running.")
    print("Plugin will POST to /scangame and a report will be written into your Downloads folder.\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


def main() -> None:
    host = os.environ.get("RSB_HOST", DEFAULT_HOST)
    port = int(os.environ.get("RSB_PORT", str(DEFAULT_PORT)))
    run_server(host, port)


if __name__ == "__main__":
    main()
