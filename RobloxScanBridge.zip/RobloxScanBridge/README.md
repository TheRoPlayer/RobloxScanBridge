# RobloxScanBridge (Python 3.12) — Roblox Plugin ↔ EXE bridge

## What you get
- **Python app** (`main.py`) that runs a tiny local server (no dependencies).
- **Roblox Studio plugin script** (`roblox_plugin/RobloxScanBridge.plugin.lua`) that scans your place (scripts/parts/models/folders etc.)
  and sends the scan to the local server by HTTP.
- The Python app writes a **.txt report into your Downloads folder** with the estimate + app/exe name.

---

## 1) Run the Python app (in VS Code)
Open this folder in VS Code, then run:

```powershell
py -3.12 .\main.py
```

You should see:

- `RobloxScanBridge running on http://127.0.0.1:8787`

Keep it open.

---

## 2) Install the plugin in Roblox Studio
You have two easy options:

### Option A — Create a plugin quickly
1. Open **Roblox Studio**
2. Create a new **Plugin** in your toolbox workflow (or use a local plugin project)
3. Paste the code from:

`roblox_plugin/RobloxScanBridge.plugin.lua`

into your plugin script.

### Option B — Manual file plugin (advanced)
You can create a local plugin folder, but Roblox’s plugin folder structure can vary.
Option A is simplest.

---

## 3) Use it
- Click the toolbar button **“Scan Game”**
- It scans the place and posts results to the Python app
- Check your **Downloads** folder for a file like:
  `RobloxScanReport_2026-02-13_18-00-00_UTC.txt`

---

## Notes / Limits
- Roblox Studio HTTP requires `HttpService.HttpEnabled = true` for the plugin to send requests.
- This estimates “complexity time” with a heuristic. It’s a rough estimate, not an official Roblox compile time.

---

## Packaging to EXE (optional)
If you want an EXE later, you can use PyInstaller.

See `build_exe.ps1`.
